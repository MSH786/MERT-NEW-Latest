const Shadow = {
  shadowColor: '#3A2D1380',
  shadowOffset: {
    width: 0,
    height: 2,
  },
  shadowOpacity: 0.25,
  shadowRadius: 3.84,
  elevation: 3,
};

export default Shadow;
