
//Navigation Header
export const profileButton = require('../../assets/images/profileButton.png');
export const studioCoin = require('../../assets/icons/studioCoin.png');
export const marketCoin = require('../../assets/icons/marketCoin.png');
export const headerLogo = require('../../assets/icons/headerLogo.png');
export const galleryIcon = require('../../assets/icons/gallery.png');

//Register
export const turkeyIcon = require('../../assets/icons/turkeyIcon.png');
