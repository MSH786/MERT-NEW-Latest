export const homeCar =
  'https://firebasestorage.googleapis.com/v0/b/datingapp-44e69.appspot.com/o/homeCar.gif?alt=media&token=070cacad-eefd-464f-9186-821bb889e9e3';
