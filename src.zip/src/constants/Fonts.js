const Fonts = {
    regular: 'Avenir-Regular',
    bold: 'Avenir-Heavy'
};



export default Fonts;