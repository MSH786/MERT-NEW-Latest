import Ilan from '../models/ilan';

export const ILANS = [
    new Ilan(),
    new Ilan(),
    new Ilan(),
    new Ilan(),
    new Ilan(),
    new Ilan(),
    new Ilan(),
    new Ilan(),
    new Ilan(),
    new Ilan(),
    new Ilan(),
    new Ilan()
];

export default ILANS;