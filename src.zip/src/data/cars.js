import CAR from '../models/car';

export const CARS = [
    new CAR(),
    new CAR(),
    new CAR(),
    new CAR(),
    new CAR(),
    new CAR(),
    new CAR(),
    new CAR(),
    new CAR(),
    new CAR(),
    new CAR(),
    new CAR()
];

export default CARS;