import Message from '../models/message';

export const MESSAGES = [
    new Message(),
    new Message(),
    new Message(),
    new Message(),
    new Message(),
    new Message(),
    new Message(),
    new Message(),
    new Message(),
    new Message(),
    new Message(),
    new Message()
];

export default MESSAGES;