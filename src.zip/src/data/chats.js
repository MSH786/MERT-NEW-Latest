import Chat from '../models/chat';

export const CHATS = [
    new Chat(),
    new Chat(),
    new Chat(),
    new Chat(),
    new Chat(),
    new Chat(),
    new Chat(),
    new Chat(),
    new Chat(),
    new Chat(),
    new Chat(),
    new Chat()
];

export default CHATS;