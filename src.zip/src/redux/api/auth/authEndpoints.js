export const loginEP = 'https://alicibul.com/login/';

export const registerEP = 'https://alicibul.com/register/';
