export const showcaseItemsEP = 'https://alicibul.com/products/';
