import React from 'react'
import { Text, View ,StyleSheet} from 'react-native'

const NotificationSettingsScreen = () => {
        return (
            <View>
                <Text> textInComponent </Text>
            </View>
        )
}

const styles = StyleSheet.create({})

export default NotificationSettingsScreen;