import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, TouchableOpacity, View, } from 'react-native';

import { useNavigation } from '@react-navigation/native';

const EditFindBuyerScreen = ({ route }) => {

  const navigation = useNavigation();
  return (
    <>
    </>
  );
};
const styles = StyleSheet.create({});

export default EditFindBuyerScreen;
