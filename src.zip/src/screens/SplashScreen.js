import React from 'react'
import { Image, View } from 'react-native'
import { CommonActions } from '@react-navigation/native';
import { useDispatch, useSelector } from "react-redux";


const SplashScreen = (props) => {


    const dispatch = useDispatch()

    return (
        <View >
            
        </View>
    )
}

export default SplashScreen


