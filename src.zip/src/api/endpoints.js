export const CREATE_TOKEN_ENDPOINT = "identity/account/createtoken"
